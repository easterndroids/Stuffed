package ca.dal.ch392748.emailattachment;

/**Author: Sandy
 * Date: 16 June, 2017
 */


import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //the following codes are standard code for sending an email from an android app
        final String subjectString = "Sending my image and location";
        final String contentString = "";
        Button buttonSendingEmail = (Button) findViewById(R.id.send);
        buttonSendingEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //the following piece of code opens an email client using intent
                Intent sendingEmailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto","kvaishali1344@gmail.com",null));
                sendingEmailIntent.putExtra(Intent.EXTRA_SUBJECT,subjectString);
                sendingEmailIntent.putExtra(Intent.EXTRA_TEXT,contentString);
                startActivity(Intent.createChooser(sendingEmailIntent,"Sending email"));
            }
        });
    }
}
