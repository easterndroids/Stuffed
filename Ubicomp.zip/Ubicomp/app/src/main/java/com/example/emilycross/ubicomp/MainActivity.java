/*
    This part of the application allows the user to take a picture and save it. It will then be sent to their parent or guardian.
    It accesses the built in camera application available on Android - this can be modified to access the camera directly if we determine that it is necessary.

    Tested on Nexus 5 API 25 Emulator.

    Based on Android lesson about accessing camera:
        https://developer.android.com/training/camera/photobasics.html
        https://appsandbiscuits.com/using-the-camera-android-14-6c61343efd04

   Other references:
        https://stackoverflow.com/questions/28156228/taking-photo-android
        https://stackoverflow.com/questions/13977245/android-open-camera-from-button
*/

package com.example.emilycross.ubicomp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.ImageView;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    /* picture path to save file */
    String pathToPicture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /* when user clicks button, take the picture */
    public void clickTakePicture(View view) {
        takePicture();
    }

    /* take picture */
    private void takePicture() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        /* make sure intent is going to work */
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            /* create file for picture */
            File pictureFile = null;
            try {
                pictureFile = createPictureFile();
            } catch (IOException ex) {
                /* catch errors */
            }
            /* if file is created successfully, continue */
            if (pictureFile != null) {
                Uri pictureURI = FileProvider.getUriForFile(this,
                        "com.example.android.fileprovider",
                        pictureFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, pictureURI);
                startActivityForResult(takePictureIntent, 1);
            }
        }
    }

    /* retrieve picture, show above button */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            File pictureFile = new  File(pathToPicture);
            /* if picture was taken, then display it */
            if(pictureFile.exists()){
                Bitmap pictureBitmap = BitmapFactory.decodeFile(pictureFile.getAbsolutePath());
                ImageView imageView = (ImageView) findViewById(R.id.imageView);
                imageView.setImageBitmap(pictureBitmap);
            }
        }

    }

    private File createPictureFile() throws IOException {
        /* use data as file name - once the rest of the application is more complete, we'll likely want to include the username */
        String dateTime = new SimpleDateFormat("yyyyMMdd_HHmm").format(new Date());
        /* ex. filename could be username_dateTime */
        String pictureFileName = dateTime;
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        /* create the file for the picture */
        File picture = File.createTempFile(
                pictureFileName, ".jpg", storageDir
        );

        /* store the path to the picture that was taken */
        pathToPicture = picture.getAbsolutePath();
        return picture;
    }

}
