package com.example.gps.myapplication;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.location.LocationListener;
import android.location.LocationManager;
import android.widget.TextView;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

/* The MainActivity and TrackGPS file allow the user to get current location, the longitude and latitude.
And then showing the street name, cityname, and country name.
When the location is changed, click the button, the interface will show the new location information.

This part is test on Android Nexus 5 API 25 Emulator.

References:
    http://www.androidhive.info/2012/07/android-gps-location-manager-tutorial/
    https://stackoverflow.com/questions/34264178/longitude-and-latitude-showing-0-0-in-service
    https://stackoverflow.com/questions/9409195/how-to-get-complete-address-from-latitude-and-longitude
*/



public class MainActivity extends AppCompatActivity implements LocationListener {
    Button get_location;
    private TrackGPS gps;
    //protected Double longitude,latitude;

    TextView city;
    TextView lon,lat;
    LocationManager locationManager;
    //listen location changes
    LocationListener locationListener;
    String GPSLocation, streetName, cityName, countryName;
    Double latitude, longitude;
    Geocoder geocoder;
    List<Address> addresses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViews();
    }

    public void findViews() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.INTERNET
                }, 10);
        } else {
            locationManager.requestLocationUpdates("gps", 5000, 0, this);

            return;
        }
        //locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
        get_location = (Button) findViewById(R.id.get_location);
        get_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!locationManager.isProviderEnabled(locationManager.GPS_PROVIDER)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    // 2. Chain together various setter methods to set the dialog characteristics
                    builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                            .setCancelable(false)
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                                    startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                                    dialog.cancel();
                                }
                            });
                    // 3. Get the AlertDialog from create()
                    AlertDialog dialog = builder.create();
                    dialog.show();
                } else {
                    // create class object

                    gps = new TrackGPS(MainActivity.this);
                    latitude = gps.getLatitude();
                    longitude = gps.getLongitude();

                    // \n is for new line
                    Toast.makeText(getApplicationContext(), "Your Location is - \nLat: "
                            + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();
                    getCompleteAddressString(latitude,longitude);
                    GPSLocation= "  Latitude: "+latitude+"\n"+"  Longtitude: "+longitude
                                +"\n"+"  StreetName: "+streetName+"\n"+"  Cityname: "+cityName+"\n"
                                +"  CountryName: "+countryName+"\n";
                    Toast.makeText(getApplicationContext(), "Your Location is - \nLocation: "
                            + GPSLocation, Toast.LENGTH_LONG).show();
                   // Toast.makeText(getApplicationContext(), "Longitude:" + Double.toString(lon) + "\nLatitude:" + Double.toString(lat), Toast.LENGTH_SHORT).show();
                    //Create a Uri from an intent string. Use the result to create an Intent.

                }
            }

        });
    }


    @Override
    public void onLocationChanged(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        Log.d("location",latitude.toString());
        getCompleteAddressString(latitude,longitude);
                    GPSLocation= "  Latitude: "+latitude+"\n"+"  Longtitude: "+longitude
                                +"\n"+"  StreetName: "+streetName+"\n"+"  Cityname: "+cityName+"\n"
                                +"  CountryName: "+countryName+"\n";
                    Toast.makeText(getApplicationContext(), "Your Location is - \nLocation: "
                            + GPSLocation, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }


    //get streetName,cityName,CountryName based on longitude and latitude
    private String getCompleteAddressString(double LATITUDE, double LONGITUDE) {
        String strAdd = "";
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1);
            if (addresses != null) {
                streetName = addresses.get(0).getAddressLine(0);
                countryName = addresses.get(0).getAddressLine(1);
                cityName = addresses.get(0).getAddressLine(2);
            } else {
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return strAdd;
    }

}


